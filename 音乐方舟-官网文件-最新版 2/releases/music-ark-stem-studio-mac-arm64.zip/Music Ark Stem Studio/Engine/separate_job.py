"""UVR-compatible engine adapter, isolated so cancellation releases model memory."""
import os
from pathlib import Path
import sys
import logging

root = Path(__file__).resolve().parent
os.environ.setdefault('HF_HOME', str(root / 'data' / 'models' / 'huggingface'))
os.environ.setdefault('TORCH_HOME', str(root / 'data' / 'models' / 'torch'))
os.environ.setdefault('PYTORCH_ENABLE_MPS_FALLBACK', '1')
import imageio_ffmpeg
ffmpeg = Path(imageio_ffmpeg.get_ffmpeg_exe())
# pydub and audio-separator require an executable named ffmpeg on PATH.
bin_dir = root / 'data' / 'bin'
bin_dir.mkdir(parents=True, exist_ok=True)
link = bin_dir / 'ffmpeg'
if not link.exists():
    link.symlink_to(ffmpeg)
os.environ['PATH'] = str(bin_dir) + os.pathsep + os.environ.get('PATH', '')
from audio_separator.separator import Separator

source, output, model, fmt, quality = sys.argv[1:]
separator = Separator(output_dir=output, output_format=fmt, model_file_dir=str(root / 'data' / 'models'), log_level=logging.INFO, demucs_params={'segment_size': 7, 'shifts': 2 if quality == 'high' else 1, 'overlap': 0.5 if quality == 'high' else 0.25, 'segments_enabled': True}, mdx_params={'hop_length': 1024, 'segment_size': 256, 'overlap': 0.5 if quality == 'high' else 0.25, 'batch_size': 1, 'enable_denoise': quality == 'high'})
print('加载模型：' + model, flush=True)
separator.load_model(model_filename=model)
print('模型就绪，正在分离音轨…', flush=True)
files = separator.separate(source)
print('已生成音轨：' + str(files), flush=True)

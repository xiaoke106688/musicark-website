#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
trap 'echo; echo "安装未完成。请保留上方错误信息；如提示缺少编译器，可先在终端运行 xcode-select --install。按回车关闭。"; read -r' ERR
if [[ "$(uname -m)" != arm64 ]]; then
  echo '此版本仅支持 Apple Silicon（M 系列）Mac。'; read -r; exit 1
fi
ROOT="$PWD/Engine"
export UV_INSTALL_DIR="$ROOT/tools"
export UV_NO_MODIFY_PATH=1
export UV_PYTHON_INSTALL_DIR="$ROOT/runtime"
export UV_CACHE_DIR="$ROOT/data/cache"
export TMPDIR="$ROOT/data/tmp"
mkdir -p "$TMPDIR" "$UV_INSTALL_DIR"
echo '音乐方舟 · 安装本地分轨引擎'
echo '首次安装需要联网下载 Python 和机器学习依赖，并占用数 GB 磁盘。音频不会上传。'
if [[ ! -x "$UV_INSTALL_DIR/uv" ]]; then
  curl --fail --location --retry 3 https://astral.sh/uv/0.13.6/install.sh -o "$TMPDIR/uv-install.sh"
  sh "$TMPDIR/uv-install.sh"
fi
"$UV_INSTALL_DIR/uv" python install 3.12
if [[ ! -x "$ROOT/.venv/bin/python" ]]; then
  "$UV_INSTALL_DIR/uv" venv --python 3.12 --managed-python "$ROOT/.venv"
fi
"$UV_INSTALL_DIR/uv" pip install --python "$ROOT/.venv/bin/python" -r "$ROOT/requirements.lock.txt"
"$ROOT/.venv/bin/python" -c 'from audio_separator.separator import Separator; import imageio_ffmpeg; print("引擎就绪")'
echo '安装完成。正在打开 Stem Studio；首次使用每个模型还会下载对应权重。'
open "$PWD/Stem Studio.app"
